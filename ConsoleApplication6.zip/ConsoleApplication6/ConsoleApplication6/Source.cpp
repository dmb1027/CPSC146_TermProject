#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

void getQuestion(int numLine) {
	string line;
	int lineCount = 0;
	ifstream myfile("TestBank.txt");
	if (myfile.is_open())
	{
		while(getline(myfile, line))
		{
			lineCount++;
			if (lineCount == numLine)
			{
				cout << line << endl;
			}
		}
	}

	else 
		cout << "Unable to open file";

	
}

void main()
{
	srand(time(0));
	int random = rand() % 101;
	getQuestion(random);
	
	system("Pause");
}